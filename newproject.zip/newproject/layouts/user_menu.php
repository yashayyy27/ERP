<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
       <span>Sales</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales.php">Manage Sales</a> </li>
         <li><a href="add_sale.php">Add Sale</a> </li>
     </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
       <span>Sales Report</span>
      </a>
      <ul class="nav submenu">
        <li><a href="sales_report.php">Sales by dates </a></li>
        <li><a href="monthly_sales.php">Monthly sales</a></li>
        <li><a href="daily_sales.php">Daily sales</a> </li>
      </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-usd"></i>
       <span>Cash & Bank</span>
      </a>
      <ul class="nav submenu">
        <li><a href="Bank_accs.php">Bank Accounts </a></li>
        <li><a href="cashin.php">Cash In Hand</a></li>
        <li><a href="cheques.php">Cheques</a> </li>
        <li><a href="loan_accs.php">Loan Accounts</a> </li>
      </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-shopping-cart"></i>
       <span>Purchase</span>
      </a>
      <ul class="nav submenu">
        <li><a href="purchase Bills.php">Purchase Bills  </a></li>
        <li><a href="payments_out.php">Payments Out</a></li>
        <li><a href="purchase_order.php">Purchase Order</a> </li>
        <li><a href="purchase_return.php">Purchase Return/ Dr.Note</a> </li>
      </ul>
  </li>
  <li>
    <a href="items.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Items</span>
    </a>
  </li>
  <li>
    <a href="myonline.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>My Online Store</span>
    </a>
  </li>
  <li>
    <a href="parties.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Parties</span>
    </a>
  </li>
</ul>
